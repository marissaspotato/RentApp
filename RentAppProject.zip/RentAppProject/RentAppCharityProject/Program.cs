using Microsoft.AspNetCore.Identity;
using Microsoft.Build.Framework;
using Microsoft.EntityFrameworkCore;
using RentAppProject;
using RentAppProject.Areas.Identity.Data;
using RentAppProject.Data;
using Stripe;
using Stripe.BillingPortal;
using Stripe.Checkout;
using System.Configuration;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration.GetConnectionString("RentAppUserContextConnection") ?? throw new InvalidOperationException("Connection string 'RentAppUserContextConnection' not found.");

builder.Services.AddDbContext<RentAppUserContext>(options =>
    options.UseSqlServer(connectionString));

// configure identity services
builder.Services.AddDefaultIdentity<RentAppUser>(options =>
{
    options.SignIn.RequireConfirmedAccount = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;

})
    .AddEntityFrameworkStores<RentAppUserContext>();


// Add services to the container.
builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddSession();

// Add stripe configuration
StripeConfiguration.ApiKey = "sk_test_51MWLvXLzleT5k5xa1BXbbQ4gQPSEozOZjs6DEp8oK4llHqLke9eYvK6kyDuApXqLdZ8oE5cKc7PLyN4NgV2uznId008wkW9jwO";


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}



app.UseSession();

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthentication();;

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
app.MapRazorPages();

app.Run();
