﻿using MessagePack;
using Microsoft.Build.Framework;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace RentAppProject.Models
{
    public class Listing
    {
        [System.ComponentModel.DataAnnotations.Key]
        public int Id { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string Title { get; set; }

        public string? Description { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public double PricePerDay { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string Address { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string City { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string State { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string Country { get; set; }

        [System.ComponentModel.DataAnnotations.Required, NotNull]
        public string ZipCode { get; set; }

        public string? ImageUrl { get; set; }

        [ForeignKey("AspNetUsers")]
        public string? OwnerId { get; set; }

        [NotMapped]
        [Display(Name="Upload Image")]
        public IFormFile? ItemImage { get; set; }

        public DateTime? DonateDate { get; set; }
        public DateTime? GiveOutDate { get; set; }
        public float? EstimatedPrice { get; set; }
        public DateTime? SoldDate { get; set; }
        public float? SoldPrice { get; set; }
        public int? ReceiverId { get; set; }
        public string? Category { get; set; }
        public string? ItemType { get; set; }
        public string? Material { get; set; }
        public int? DonatorId { get; set; }
        public string? Status { get; set; }
        public float? PredictPrice { get; set; }

    }
}
