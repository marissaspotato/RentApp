﻿using Microsoft.AspNetCore.Mvc;
using Stripe.Checkout;
using Stripe;
using Stripe.BillingPortal;
using Stripe.Checkout;
using System.Configuration;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using RentAppProject.Areas.Identity.Data;
using RentAppProject.Data;

namespace RentAppProject.Controllers
{
    public class PaymentsController : Controller
    {
        private readonly RentAppUserContext _context;
        private readonly UserManager<RentAppUser> _userManager;

        public PaymentsController(RentAppUserContext context, UserManager<RentAppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
            StripeConfiguration.ApiKey = "sk_test_51MWLvXLzleT5k5xa1BXbbQ4gQPSEozOZjs6DEp8oK4llHqLke9eYvK6kyDuApXqLdZ8oE5cKc7PLyN4NgV2uznId008wkW9jwO";
        }

        public IActionResult success()
        {
            return View();
        }

        public IActionResult cancel()
        {
            return View();
        }

        [HttpPost("create-checkout-session")]
        public async Task<ActionResult> CreateCheckoutSession()
        {
            var user = await _userManager.GetUserAsync(HttpContext.User);

            var listingId = HttpContext.Session.GetInt32("listingId");
            var resId = HttpContext.Session.GetInt32("resId");

            var listing = await _context.Listing.FindAsync(listingId);
            var reserve = await _context.Reservation.FindAsync(resId);

            var user2 = await _userManager.FindByIdAsync(listing.OwnerId);

            var options = new Stripe.Checkout.SessionCreateOptions
            {
                LineItems = new List<SessionLineItemOptions>
                {
                    new SessionLineItemOptions
                    {
                        PriceData = new SessionLineItemPriceDataOptions
                        {
                            UnitAmount = ((long?)reserve.TotalCost) * 100,
                            Currency = "usd",
                            ProductData = new SessionLineItemPriceDataProductDataOptions
                            {
                                Name = listing.Title,
                            },
                        },
                        Quantity = 1,
                    },
                },
                //PaymentIntentData = new SessionPaymentIntentDataOptions
                //{
                //    ApplicationFeeAmount = 123,
                //    TransferData = new SessionPaymentIntentDataTransferDataOptions
                //    {
                //        Destination = user2.StripeId,
                //    }
                //},
                Mode = "payment",
                SuccessUrl = "https://localhost:44375/payments/success",
                CancelUrl = "https://localhost:44375/payments/cancel",
            };

            var service = new Stripe.Checkout.SessionService();
            Stripe.Checkout.Session session = service.Create(options);

            Response.Headers.Add("Location", session.Url);
            return new StatusCodeResult(303);
        }
    }
}
