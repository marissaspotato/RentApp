﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace RentAppProject.Migrations
{
    /// <inheritdoc />
    public partial class CharitySchema : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "City",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemType",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Location",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Material",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Quantity",
                table: "Reservation",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "State",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Reservation",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Category",
                table: "Listing",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "DonateDate",
                table: "Listing",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "DonatorId",
                table: "Listing",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "EstimatedPrice",
                table: "Listing",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "GiveOutDate",
                table: "Listing",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ItemType",
                table: "Listing",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Material",
                table: "Listing",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "PredictPrice",
                table: "Listing",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "ReceiverId",
                table: "Listing",
                type: "int",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "SoldDate",
                table: "Listing",
                type: "datetime2",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "SoldPrice",
                table: "Listing",
                type: "real",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Listing",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Category",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "City",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "ItemType",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "Location",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "Material",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "Quantity",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "State",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Reservation");

            migrationBuilder.DropColumn(
                name: "Category",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "DonateDate",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "DonatorId",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "EstimatedPrice",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "GiveOutDate",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "ItemType",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "Material",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "PredictPrice",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "ReceiverId",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "SoldDate",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "SoldPrice",
                table: "Listing");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Listing");
        }
    }
}
