﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using RentAppProject.Areas.Identity.Data;
using RentAppProject.Data;
using RentAppProject.Models;
using Stripe;

namespace RentAppProject.Controllers
{
    [Authorize]
    public class ListingsController : Controller
    {
        private readonly RentAppUserContext _context;
        private readonly UserManager<RentAppUser> _userManager;
        private readonly IWebHostEnvironment _hostEnvironment;

        public ListingsController(RentAppUserContext context, UserManager<RentAppUser> userManager, IWebHostEnvironment hostEnvironment)
        {
            _context = context;
            _userManager = userManager;
            _hostEnvironment = hostEnvironment;
        }

        [BindProperty]
        public Listing FileUpload { get; set; }

        // GET: Listings
        [AllowAnonymous]
        public async Task<IActionResult> Index(string searchString)
        {
            var items = from i in _context.Listing
                        select i;

            if (!String.IsNullOrEmpty(searchString))
            {
                items = items.Where(s => s.Title!.Contains(searchString));
            }

            return View(await items.ToListAsync());
        }

        // GET: Listings/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Listing == null)
            {
                return NotFound();
            }

            var listing = await _context.Listing
                .FirstOrDefaultAsync(m => m.Id == id);
            if (listing == null)
            {
                return NotFound();
            }

            HttpContext.Session.SetInt32("listingId", listing.Id);

            return View(listing);
        }

        // GET: Listings/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Listings/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Title,Description,PricePerDay,Address,City,State,Country,ZipCode,ImageUrl,OwnerId")] Listing listing)
        {
            if (ModelState.IsValid)
            {
                // upload image to folder
                if (FileUpload.ItemImage.Length > 0)
                {
                    var fileName = DateTime.Now.ToString("yMMddhhmmssfff") + FileUpload.ItemImage.FileName;
                    using (var stream = new FileStream(Path.Combine(_hostEnvironment.WebRootPath, "img", fileName), FileMode.Create))
                    {
                        await FileUpload.ItemImage.CopyToAsync(stream);
                    }

                    listing.ImageUrl = fileName;
                }
                
                var user = await _userManager.GetUserAsync(HttpContext.User);
                listing.OwnerId = user.Id;

                if (user.StripeId == null)
                {
                    // create an express connected account
                    var options = new AccountCreateOptions
                    {
                        Type = "express",
                        Country = "US",
                        Capabilities = new AccountCapabilitiesOptions
                        {
                            CardPayments = new AccountCapabilitiesCardPaymentsOptions { Requested = true },
                            Transfers = new AccountCapabilitiesTransfersOptions { Requested = true },
                        },
                        BusinessType = "individual",
                    };
                    var service = new AccountService();
                    var account = service.Create(options);

                    user.StripeId = account.Id;
                }

                //create account link
                var options1 = new AccountLinkCreateOptions
                {
                    Account = user.StripeId,
                    RefreshUrl = "https://example.com/reauth",
                    ReturnUrl = "https://example.com/return",
                    Type = "account_onboarding",
                };
                var service1 = new AccountLinkService();
                service1.Create(options1);


                HttpContext.Session.SetString("userId", user.Id);


                _context.Add(listing);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(listing);
        }

        // GET: Listings/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Listing == null)
            {
                return NotFound();
            }

            var listing = await _context.Listing.FindAsync(id);
            if (listing == null)
            {
                return NotFound();
            }
            return View(listing);
        }

        // POST: Listings/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Title,Description,PricePerDay,Address,City,State,Country,ZipCode,ImageUrl,OwnerId")] Listing listing)
        {
            if (id != listing.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var user = await _userManager.GetUserAsync(HttpContext.User);
                    listing.OwnerId = user.Id;

                    _context.Update(listing);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ListingExists(listing.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(listing);
        }

        // GET: Listings/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Listing == null)
            {
                return NotFound();
            }

            var listing = await _context.Listing
                .FirstOrDefaultAsync(m => m.Id == id);
            if (listing == null)
            {
                return NotFound();
            }

            return View(listing);
        }

        // POST: Listings/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Listing == null)
            {
                return Problem("Entity set 'RentAppUserContext.Listing'  is null.");
            }
            var listing = await _context.Listing.FindAsync(id);
            if (listing != null)
            {
                _context.Listing.Remove(listing);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ListingExists(int id)
        {
          return _context.Listing.Any(e => e.Id == id);
        }
    }
}
