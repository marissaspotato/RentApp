﻿using MessagePack;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations.Schema;

namespace RentAppProject.Models
{
    public class Reservation
    {
        [System.ComponentModel.DataAnnotations.Key]
        public int ReservationId { get; set; }

        [ForeignKey("AspNetUsers")]
        public string? UserId { get; set; }

        [ForeignKey("Listing")]
        public int ListingId { get; set; }

        [DisplayName("Start Date")]
        public DateTime StartDate { get; set; }

        [DisplayName("End Date")]
        public DateTime EndDate { get; set; }

        public double? TotalCost { get; set; }
    }
}
